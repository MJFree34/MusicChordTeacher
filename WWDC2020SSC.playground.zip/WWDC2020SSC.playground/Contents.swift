import AVKit
import PlaygroundSupport
import UIKit

// MARK: - Enums
enum Constants {
    static let staffWidth: CGFloat = 350
    static let imageSizeDividend: CGFloat = 400 / Constants.staffWidth * 2
}

enum ColorLevel {
    case standard
    case mild
    case low
    case decent
    case high
    case extreme
}

enum Clef {
    case bass
    case treble
}

enum Note: CaseIterable {
    case c3
    case eMajor
    case ebMinor
    case g
    case aMajor
    case aMinor
    case bMajor
    case bbMinor
    case c4
}

// MARK: - Extensions
extension UIView {
    func pinToCenter() {
        centerXAnchor.constraint(equalTo: superview!.centerXAnchor).isActive = true
        centerYAnchor.constraint(equalTo: superview!.centerYAnchor).isActive = true
    }
    
    func animateViewBackground(for duration: TimeInterval, color: UIColor) {
        UIView.animate(withDuration: duration) {
            self.backgroundColor = color
        }
    }
    
    func animateAlpha(for duration: TimeInterval, reveal: Bool) {
        if reveal {
            UIView.animate(withDuration: duration) {
                self.alpha = 1
            }
        } else {
            UIView.animate(withDuration: duration) {
                self.alpha = 0
            }
        }
    }
    
    func animateScale(for duration: TimeInterval, reveal: Bool) {
        if reveal {
            UIView.animate(withDuration: duration) {
                self.transform = CGAffineTransform(scaleX: 1, y: 1)
            }
        } else {
            UIView.animate(withDuration: duration) {
                self.transform = CGAffineTransform(scaleX: 0.01, y: 0.01)
            }
        }
    }
}

extension UIImage {
    static func drawStaffLine(color: UIColor) -> UIImage {
        let size = CGSize(width: Constants.staffWidth, height: 4)
        
        let renderer = UIGraphicsImageRenderer(size: size)
        
        let img = renderer.image { ctx in
            ctx.cgContext.setFillColor(color.cgColor)
            ctx.cgContext.fill(CGRect(origin: .zero, size: size))
        }
        
        return img
    }
}

extension UIColor {
    static func random() -> UIColor {
        let colors = [UIColor.blue, UIColor.systemRed, UIColor.systemBlue, UIColor.systemPink, UIColor.systemTeal, UIColor.systemGreen, UIColor.systemIndigo, UIColor.systemOrange, UIColor.systemPurple, UIColor.systemYellow, UIColor.brown, UIColor.cyan, UIColor.green, UIColor.magenta, UIColor.orange, UIColor.purple, UIColor.red, UIColor.yellow]
        return colors.randomElement()!
    }
}

extension UILabel {
    func animateTextChange(for duration: TimeInterval, text: String, color: UIColor) {
        UIView.transition(with: self, duration: duration, options: .transitionCrossDissolve, animations: {
            self.text = text
            self.textColor = color
        }, completion: nil)
    }
}

// MARK: - Models
struct TrombonePlayerController {
    private var playerForC3: AVAudioPlayer?
    private var playerForC4: AVAudioPlayer?
    private var playerForEMajor: AVAudioPlayer?
    private var playerForEbMinor: AVAudioPlayer?
    private var playerForG: AVAudioPlayer?
    private var playerForAMajor: AVAudioPlayer?
    private var playerForAMinor: AVAudioPlayer?
    private var playerForBMajor: AVAudioPlayer?
    private var playerForBbMinor: AVAudioPlayer?
    
    init() {
        do {
            let url = Bundle.main.url(forResource: "C3", withExtension: "mp3")!
            playerForC3 = try AVAudioPlayer(contentsOf: url)
            playerForC3?.numberOfLoops = -1
            playerForC3?.volume = 0
        } catch {
            print(error.localizedDescription)
        }
        
        do {
            let url = Bundle.main.url(forResource: "C4", withExtension: "mp3")!
            playerForC4 = try AVAudioPlayer(contentsOf: url)
            playerForC4?.numberOfLoops = -1
            playerForC4?.volume = 0
        } catch {
            print(error.localizedDescription)
        }
        
        do {
            let url = Bundle.main.url(forResource: "Emajor", withExtension: "mp3")!
            playerForEMajor = try AVAudioPlayer(contentsOf: url)
            playerForEMajor?.numberOfLoops = -1
            playerForEMajor?.volume = 0
        } catch {
            print(error.localizedDescription)
        }
        
        do {
            let url = Bundle.main.url(forResource: "Ebminor", withExtension: "mp3")!
            playerForEbMinor = try AVAudioPlayer(contentsOf: url)
            playerForEbMinor?.numberOfLoops = -1
            playerForEbMinor?.volume = 0
        } catch {
            print(error.localizedDescription)
        }
        
        do {
            let url = Bundle.main.url(forResource: "G", withExtension: "mp3")!
            playerForG = try AVAudioPlayer(contentsOf: url)
            playerForG?.numberOfLoops = -1
            playerForG?.volume = 0
        } catch {
            print(error.localizedDescription)
        }
        
        do {
            let url = Bundle.main.url(forResource: "Amajor", withExtension: "mp3")!
            playerForAMajor = try AVAudioPlayer(contentsOf: url)
            playerForAMajor?.numberOfLoops = -1
            playerForAMajor?.volume = 0
        } catch {
            print(error.localizedDescription)
        }
        
        do {
            let url = Bundle.main.url(forResource: "Aminor", withExtension: "mp3")!
            playerForAMinor = try AVAudioPlayer(contentsOf: url)
            playerForAMinor?.numberOfLoops = -1
            playerForAMinor?.volume = 0
        } catch {
            print(error.localizedDescription)
        }
        
        do {
            let url = Bundle.main.url(forResource: "Bmajor", withExtension: "mp3")!
            playerForBMajor = try AVAudioPlayer(contentsOf: url)
            playerForBMajor?.numberOfLoops = -1
            playerForBMajor?.volume = 0
        } catch {
            print(error.localizedDescription)
        }
        
        do {
            let url = Bundle.main.url(forResource: "Bbminor", withExtension: "mp3")!
            playerForBbMinor = try AVAudioPlayer(contentsOf: url)
            playerForBbMinor?.numberOfLoops = -1
            playerForBbMinor?.volume = 0
        } catch {
            print(error.localizedDescription)
        }
        
        playAllSilently()
    }
    
    func playNote(_ note: Note, volume: Float = 1, fadeDuration: TimeInterval = 2) {
        switch note {
        case .c3:
            playerForC3?.play()
            playerForC3?.setVolume(volume, fadeDuration: fadeDuration)
        case .eMajor:
            playerForEMajor?.play()
            playerForEMajor?.setVolume(volume, fadeDuration: fadeDuration)
        case .ebMinor:
            playerForEbMinor?.play()
            playerForEbMinor?.setVolume(volume, fadeDuration: fadeDuration)
        case .g:
            playerForG?.play()
            playerForG?.setVolume(volume, fadeDuration: fadeDuration)
        case .aMajor:
            playerForAMajor?.play()
            playerForAMajor?.setVolume(volume, fadeDuration: fadeDuration)
        case .aMinor:
            playerForAMinor?.play()
            playerForAMinor?.setVolume(volume, fadeDuration: fadeDuration)
        case .bMajor:
            playerForBMajor?.play()
            playerForBMajor?.setVolume(volume, fadeDuration: fadeDuration)
        case .bbMinor:
            playerForBbMinor?.play()
            playerForBbMinor?.setVolume(volume, fadeDuration: fadeDuration)
        case .c4:
            playerForC4?.play()
            playerForC4?.setVolume(volume, fadeDuration: fadeDuration)
        }
    }
    
    func playAll() {
        for note in Note.allCases {
            playNote(note)
        }
    }
    
    func playAllSilently() {
        for note in Note.allCases {
            playNote(note, volume: 0, fadeDuration: 0)
        }
    }
    
    func stopPlayingNote(_ note: Note) {
        switch note {
        case .c3:
            playerForC3?.setVolume(0, fadeDuration: 2)
        case .eMajor:
            playerForEMajor?.setVolume(0, fadeDuration: 2)
        case .ebMinor:
            playerForEbMinor?.setVolume(0, fadeDuration: 2)
        case .g:
            playerForG?.setVolume(0, fadeDuration: 2)
        case .aMajor:
            playerForAMajor?.setVolume(0, fadeDuration: 2)
        case .aMinor:
            playerForAMinor?.setVolume(0, fadeDuration: 2)
        case .bMajor:
            playerForBMajor?.setVolume(0, fadeDuration: 2)
        case .bbMinor:
            playerForBbMinor?.setVolume(0, fadeDuration: 2)
        case .c4:
            playerForC4?.setVolume(0, fadeDuration: 2)
        }
    }
    
    func stopAll() {
        for note in Note.allCases {
            stopPlayingNote(note)
        }
    }
    
    func isPlayingNote(_ note: Note) -> Bool {
        switch note {
        case .c3:
            return (playerForC3?.volume == 1)
        case .eMajor:
            return (playerForEMajor?.volume == 1)
        case .ebMinor:
            return (playerForEbMinor?.volume == 1)
        case .g:
            return (playerForG?.volume == 1)
        case .aMajor:
            return (playerForAMajor?.volume == 1)
        case .aMinor:
            return (playerForAMinor?.volume == 1)
        case .bMajor:
            return (playerForBMajor?.volume == 1)
        case .bbMinor:
            return (playerForBbMinor?.volume == 1)
        case .c4:
            return (playerForC4?.volume == 1)
        }
    }
}

// MARK: - Views
class StaffView: UIView {
    let c3Note = UIImageView()
    let eNote = UIImageView()
    let ebNote = UIImageView()
    let gNote = UIImageView()
    let aNote = UIImageView()
    let bNote = UIImageView()
    let bbNote = UIImageView()
    let c4Note = UIImageView()
    
    init(of clef: Clef) {
        super.init(frame: CGRect(x: 0, y: 0, width: Constants.staffWidth, height: Constants.staffWidth / 2))
        
        addLines()
        addClef(clef)
        addNotes()
        
        translatesAutoresizingMaskIntoConstraints = false
    }
    
    func addLines() {
        for i in -2...2 {
            let staffImageView = UIImageView(image: UIImage.drawStaffLine(color: .clear))
            staffImageView.backgroundColor = .black
            staffImageView.translatesAutoresizingMaskIntoConstraints = false
            addSubview(staffImageView)
            
            staffImageView.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true
            staffImageView.centerYAnchor.constraint(equalTo: centerYAnchor, constant: Constants.staffWidth / 8 * CGFloat(i)).isActive = true
        }
    }
    
    func addClef(_ clef: Clef) {
        switch clef {
        case .bass:
            let bassPath = Bundle.main.path(forResource: "BassClef", ofType: "png")!
            let bassClef = UIImageView(image: UIImage(contentsOfFile: bassPath))
            bassClef.translatesAutoresizingMaskIntoConstraints = false
            addSubview(bassClef)
            
            bassClef.centerYAnchor.constraint(equalTo: centerYAnchor, constant: -20).isActive = true
            bassClef.leadingAnchor.constraint(equalTo: leadingAnchor, constant: -170).isActive = true
            bassClef.heightAnchor.constraint(equalToConstant: bassClef.bounds.height / Constants.imageSizeDividend).isActive = true
            bassClef.widthAnchor.constraint(equalToConstant: bassClef.bounds.width / Constants.imageSizeDividend).isActive = true
        case .treble:
            let treblePath = Bundle.main.path(forResource: "TrebleClef", ofType: "png")!
            let trebleClef = UIImageView(image: UIImage(contentsOfFile: treblePath))
            trebleClef.translatesAutoresizingMaskIntoConstraints = false
            addSubview(trebleClef)
            
            trebleClef.centerYAnchor.constraint(equalTo: centerYAnchor, constant: 5).isActive = true
            trebleClef.leadingAnchor.constraint(equalTo: leadingAnchor, constant: -170).isActive = true
            trebleClef.heightAnchor.constraint(equalToConstant: trebleClef.bounds.height / Constants.imageSizeDividend).isActive = true
            trebleClef.widthAnchor.constraint(equalToConstant: trebleClef.bounds.width / Constants.imageSizeDividend).isActive = true
        }
    }
    
    func addNotes() {
        let flippedQuarterNoteWithLinePath = Bundle.main.path(forResource: "FlippedQuarterNoteWithLine", ofType: "png")!
        let flippedQuarterNoteWithFlat = Bundle.main.path(forResource: "FlippedQuarterNoteWithFlat", ofType: "png")!
        let flippedQuarterNotePath = Bundle.main.path(forResource: "FlippedQuarterNote", ofType: "png")!
        let quarterNotePath = Bundle.main.path(forResource: "QuarterNote", ofType: "png")!
        
        c3Note.image = UIImage(contentsOfFile: quarterNotePath)
        c3Note.alpha = 0
        c3Note.translatesAutoresizingMaskIntoConstraints = false
        addSubview(c3Note)
        
        c3Note.centerYAnchor.constraint(equalTo: centerYAnchor, constant: -42).isActive = true
        c3Note.centerXAnchor.constraint(equalTo: centerXAnchor, constant: -30).isActive = true
        c3Note.heightAnchor.constraint(equalToConstant: c3Note.bounds.height / Constants.imageSizeDividend).isActive = true
        c3Note.widthAnchor.constraint(equalToConstant: c3Note.bounds.width / Constants.imageSizeDividend).isActive = true
        
        eNote.image = UIImage(contentsOfFile: flippedQuarterNotePath)
        eNote.alpha = 0
        eNote.translatesAutoresizingMaskIntoConstraints = false
        addSubview(eNote)
        
        eNote.centerYAnchor.constraint(equalTo: centerYAnchor, constant: 35).isActive = true
        eNote.leadingAnchor.constraint(equalTo: c3Note.trailingAnchor, constant: 9).isActive = true
        eNote.heightAnchor.constraint(equalToConstant: eNote.bounds.height / Constants.imageSizeDividend).isActive = true
        eNote.widthAnchor.constraint(equalToConstant: eNote.bounds.width / Constants.imageSizeDividend).isActive = true
        
        ebNote.image = UIImage(contentsOfFile: flippedQuarterNoteWithFlat)
        ebNote.alpha = 0
        ebNote.translatesAutoresizingMaskIntoConstraints = false
        addSubview(ebNote)
        
        ebNote.centerYAnchor.constraint(equalTo: centerYAnchor, constant: 5.5).isActive = true
        ebNote.leadingAnchor.constraint(equalTo: c3Note.trailingAnchor, constant: -40).isActive = true
        ebNote.heightAnchor.constraint(equalToConstant: ebNote.bounds.height / Constants.imageSizeDividend).isActive = true
        ebNote.widthAnchor.constraint(equalToConstant: ebNote.bounds.width / Constants.imageSizeDividend).isActive = true
        
        gNote.image = UIImage(contentsOfFile: flippedQuarterNotePath)
        gNote.alpha = 0
        gNote.translatesAutoresizingMaskIntoConstraints = false
        addSubview(gNote)
        
        gNote.centerYAnchor.constraint(equalTo: centerYAnchor, constant: -9).isActive = true
        gNote.leadingAnchor.constraint(equalTo: eNote.trailingAnchor, constant: 5).isActive = true
        gNote.heightAnchor.constraint(equalToConstant: gNote.bounds.height / Constants.imageSizeDividend).isActive = true
        gNote.widthAnchor.constraint(equalToConstant: gNote.bounds.width / Constants.imageSizeDividend).isActive = true
        
        aNote.image = UIImage(contentsOfFile: flippedQuarterNotePath)
        aNote.alpha = 0
        aNote.translatesAutoresizingMaskIntoConstraints = false
        addSubview(aNote)
        
        aNote.centerYAnchor.constraint(equalTo: centerYAnchor, constant: -31).isActive = true
        aNote.leadingAnchor.constraint(equalTo: gNote.trailingAnchor, constant: 5).isActive = true
        aNote.heightAnchor.constraint(equalToConstant: aNote.bounds.height / Constants.imageSizeDividend).isActive = true
        aNote.widthAnchor.constraint(equalToConstant: aNote.bounds.width / Constants.imageSizeDividend).isActive = true
        
        bNote.image = UIImage(contentsOfFile: flippedQuarterNotePath)
        bNote.alpha = 0
        bNote.translatesAutoresizingMaskIntoConstraints = false
        addSubview(bNote)
        
        bNote.centerYAnchor.constraint(equalTo: centerYAnchor, constant: -53).isActive = true
        bNote.leadingAnchor.constraint(equalTo: gNote.trailingAnchor, constant: 5).isActive = true
        bNote.heightAnchor.constraint(equalToConstant: bNote.bounds.height / Constants.imageSizeDividend).isActive = true
        bNote.widthAnchor.constraint(equalToConstant: bNote.bounds.width / Constants.imageSizeDividend).isActive = true
        
        bbNote.image = UIImage(contentsOfFile: flippedQuarterNoteWithFlat)
        bbNote.alpha = 0
        bbNote.translatesAutoresizingMaskIntoConstraints = false
        addSubview(bbNote)
        
        bbNote.centerYAnchor.constraint(equalTo: centerYAnchor, constant: -82.5).isActive = true
        bbNote.leadingAnchor.constraint(equalTo: gNote.trailingAnchor, constant: -44).isActive = true
        bbNote.heightAnchor.constraint(equalToConstant: bbNote.bounds.height / Constants.imageSizeDividend).isActive = true
        bbNote.widthAnchor.constraint(equalToConstant: bbNote.bounds.width / Constants.imageSizeDividend).isActive = true
        
        c4Note.image = UIImage(contentsOfFile: flippedQuarterNoteWithLinePath)
        c4Note.alpha = 0
        c4Note.translatesAutoresizingMaskIntoConstraints = false
        addSubview(c4Note)
        
        c4Note.centerYAnchor.constraint(equalTo: centerYAnchor, constant: -75).isActive = true
        c4Note.leadingAnchor.constraint(equalTo: gNote.trailingAnchor, constant: -17.5).isActive = true
        c4Note.heightAnchor.constraint(equalToConstant: c4Note.bounds.height / Constants.imageSizeDividend).isActive = true
        c4Note.widthAnchor.constraint(equalToConstant: c4Note.bounds.width / Constants.imageSizeDividend).isActive = true
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

class TrombonePlayButton: UIButton {
    let note: Note
    
    required init(note: Note) {
        self.note = note
        
        super.init(frame: .zero)
        
        layer.cornerRadius = 10
        layer.borderWidth = 2
        
        titleLabel?.numberOfLines = 0
        titleLabel?.font = UIFont.systemFont(ofSize: 20)
        
        switch note {
        case .c3:
            layer.borderColor = UIColor.blue.cgColor
            setTitle("Root C", for: .normal)
            setTitleColor(.blue, for: .normal)
        case .eMajor:
            layer.borderColor = UIColor.purple.cgColor
            setTitle("3rd E\nMajor", for: .normal)
            setTitleColor(.purple, for: .normal)
        case .ebMinor:
            layer.borderColor = UIColor.green.cgColor
            setTitle("3rd Eb Minor", for: .normal)
            setTitleColor(.green, for: .normal)
        case .g:
            layer.borderColor = UIColor.systemTeal.cgColor
            setTitle("5th G", for: .normal)
            setTitleColor(.systemTeal, for: .normal)
        case .aMajor:
            layer.borderColor = UIColor.red.cgColor
            setTitle("6th A Major", for: .normal)
            setTitleColor(.red, for: .normal)
        case .aMinor:
            layer.borderColor = UIColor.cyan.cgColor
            setTitle("6th A Minor", for: .normal)
            setTitleColor(.cyan, for: .normal)
        case .bMajor:
            layer.borderColor = UIColor.magenta.cgColor
            setTitle("7th B\nMajor", for: .normal)
            setTitleColor(.magenta, for: .normal)
        case .bbMinor:
            layer.borderColor = UIColor.orange.cgColor
            setTitle("7th Bb Minor", for: .normal)
            setTitleColor(.orange, for: .normal)
        case .c4:
            layer.borderColor = UIColor.systemPink.cgColor
            setTitle("Octave Root C", for: .normal)
            setTitleColor(.systemPink, for: .normal)
        }
        
        showsTouchWhenHighlighted = true
        translatesAutoresizingMaskIntoConstraints = false
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

// MARK: - View Controllers
class StartViewController: UIViewController {
    let trombonePlayerController = TrombonePlayerController()
    
    var titleLabel = UILabel()
    var nextButton = UIButton(type: .custom)
    var explodeButton = UIButton(type: .custom)
    
    var gravityViews = [UIView]()
    var animator: UIDynamicAnimator?
    var exploded = false
    
    override func loadView() {
        super.loadView()
        
        view = UIView()
        view.backgroundColor = .white
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationController?.isNavigationBarHidden = true
        
        addViews()
    }
    
    func addViews() {
        let trebleStaff = StaffView(of: .treble)
        view.addSubview(trebleStaff)
        
        trebleStaff.pinToCenter()
        
        let wholeNotePath = Bundle.main.path(forResource: "WholeNote", ofType: "png")!
        let wholeNote = UIImageView(image: UIImage(contentsOfFile: wholeNotePath))
        wholeNote.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(wholeNote)
        
        wholeNote.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: -23).isActive = true
        wholeNote.centerXAnchor.constraint(equalTo: view.centerXAnchor, constant: -25).isActive = true
        wholeNote.heightAnchor.constraint(equalToConstant: wholeNote.bounds.height / 2).isActive = true
        wholeNote.widthAnchor.constraint(equalToConstant: wholeNote.bounds.width / 2).isActive = true

        let eighthNotePath = Bundle.main.path(forResource: "EighthNote", ofType: "png")!
        let eighthNote = UIImageView(image: UIImage(contentsOfFile: eighthNotePath))
        eighthNote.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(eighthNote)

        eighthNote.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: -2.5).isActive = true
        eighthNote.leadingAnchor.constraint(equalTo: wholeNote.trailingAnchor, constant: -15).isActive = true
        eighthNote.heightAnchor.constraint(equalToConstant: eighthNote.bounds.height / 2).isActive = true
        eighthNote.widthAnchor.constraint(equalToConstant: eighthNote.bounds.width / 2).isActive = true
        
        let halfNotePath = Bundle.main.path(forResource: "HalfNote", ofType: "png")!
        let halfNote = UIImageView(image: UIImage(contentsOfFile: halfNotePath))
        halfNote.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(halfNote)

        halfNote.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: -31).isActive = true
        halfNote.leadingAnchor.constraint(equalTo: eighthNote.trailingAnchor, constant: 15).isActive = true
        halfNote.heightAnchor.constraint(equalToConstant: halfNote.bounds.height / 2).isActive = true
        halfNote.widthAnchor.constraint(equalToConstant: halfNote.bounds.width / 2).isActive = true
        
        explodeButton.setTitle("Start", for: .normal)
        explodeButton.setTitleColor(.black, for: .normal)
        explodeButton.titleLabel?.font = UIFont.systemFont(ofSize: 30, weight: .ultraLight)
        explodeButton.addTarget(self, action: #selector(startNextActivity), for: .touchUpInside)
        explodeButton.titleLabel?.textAlignment = .center
        explodeButton.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(explodeButton)

        explodeButton.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        explodeButton.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20).isActive = true
        explodeButton.widthAnchor.constraint(equalToConstant: 200).isActive = true
        explodeButton.heightAnchor.constraint(equalToConstant: 50).isActive = true
        
        titleLabel.font = UIFont.systemFont(ofSize: 40, weight: .bold)
        titleLabel.textAlignment = .center
        titleLabel.text = "MUSIC\nDECONSTRUCTED"
        titleLabel.numberOfLines = 2
        titleLabel.textColor = .cyan
        titleLabel.animateScale(for: 0, reveal: false)
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(titleLabel)

        titleLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        titleLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor).isActive = true

        nextButton.setTitle("Start Journey", for: .normal)
        nextButton.setTitleColor(.systemPink, for: .normal)
        nextButton.titleLabel?.font = UIFont.systemFont(ofSize: 20, weight: .light)
        nextButton.addTarget(self, action: #selector(goToNextVC), for: .touchUpInside)
        nextButton.titleLabel?.textAlignment = .center
        nextButton.animateScale(for: 0, reveal: false)
        nextButton.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(nextButton)

        nextButton.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        nextButton.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 10).isActive = true
        nextButton.widthAnchor.constraint(equalToConstant: 200).isActive = true
        nextButton.heightAnchor.constraint(equalToConstant: 50).isActive = true
        
        gravityViews.append(contentsOf: [wholeNote, eighthNote, halfNote, explodeButton])
    }
    
    @objc func startNextActivity() {
        guard !exploded else { return }
        
        exploded = true
        trombonePlayerController.playAll()
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) { [unowned self] in
            self.trombonePlayerController.stopAll()
        }
        
        let gravity = UIGravityBehavior(items: gravityViews)
        animator = UIDynamicAnimator(referenceView: view)
        animator?.addBehavior(gravity)
        
        let collisions = UICollisionBehavior(items: gravityViews)
        
        collisions.translatesReferenceBoundsIntoBoundary = true
        animator?.addBehavior(collisions)
        
        titleLabel.animateScale(for: 1, reveal: true)
        nextButton.animateScale(for: 1, reveal: true)
    }
    
    @objc func goToNextVC() {
        let vc = ClefViewController()
        vc.trombonePlayerController = trombonePlayerController
        navigationController?.pushViewController(vc, animated: true)
    }
}

class ClefViewController: UIViewController {
    var trombonePlayerController: TrombonePlayerController!
    
    let trebleStaff = StaffView(of: .treble)
    let bassStaff = StaffView(of: .bass)
    
    let c3Note = UIImageView()
    
    let middleLabel = UILabel()
    let topLabel = UILabel()
    
    let nextButton = UIButton(type: .custom)
    
    override func loadView() {
        super.loadView()
        
        view = UIView()
        view.backgroundColor = .white
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationController?.isNavigationBarHidden = true
        
        addViews()
        
        view.animateViewBackground(for: 0, color: UIColor.random())
        trebleStaff.transform = CGAffineTransform(translationX: 0, y: 350)
        bassStaff.transform = CGAffineTransform(translationX: 0, y: -350)
        nextButton.transform = CGAffineTransform(scaleX: 0.01, y: 0.01)

        animateTrebleClef()

        DispatchQueue.main.asyncAfter(deadline: .now() + 7) {
            self.animateBassClef()
        }

        DispatchQueue.main.asyncAfter(deadline: .now() + 16) {
            self.animateDestroyTrebleClef()
        }

        DispatchQueue.main.asyncAfter(deadline: .now() + 22) {
            self.majorCSimulation()
        }

        DispatchQueue.main.asyncAfter(deadline: .now() + 49) {
            self.minorCSimulation()
        }
    }
    
    func addViews() {
        view.addSubview(trebleStaff)
        
        trebleStaff.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        trebleStaff.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: 150).isActive = true
        
        view.addSubview(bassStaff)
        
        bassStaff.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        bassStaff.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: -150).isActive = true
        
        middleLabel.font = UIFont.systemFont(ofSize: 30)
        middleLabel.textAlignment = .center
        middleLabel.text = "This is a Treble Clef"
        middleLabel.textColor = .white
        middleLabel.alpha = 0
        middleLabel.numberOfLines = 0
        middleLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(middleLabel)
        
        middleLabel.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: -20).isActive = true
        middleLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        
        topLabel.font = UIFont.systemFont(ofSize: 30)
        topLabel.textAlignment = .center
        topLabel.text = "Let's start with\nthe C major chords"
        topLabel.textColor = .black
        topLabel.alpha = 0
        topLabel.numberOfLines = 0
        topLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(topLabel)
        
        topLabel.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: -200).isActive = true
        topLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        
        nextButton.setTitle("Next Activity", for: .normal)
        nextButton.setTitleColor(.systemPink, for: .normal)
        nextButton.titleLabel?.font = UIFont.systemFont(ofSize: 30, weight: .bold)
        nextButton.addTarget(self, action: #selector(goToNextVC), for: .touchUpInside)
        nextButton.titleLabel?.textAlignment = .center
        nextButton.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(nextButton)
        
        nextButton.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        nextButton.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -20).isActive = true
        nextButton.heightAnchor.constraint(equalToConstant: 44).isActive = true
        nextButton.widthAnchor.constraint(equalToConstant: 200).isActive = true
    }
    
    func animateTrebleClef() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
            self.view.animateViewBackground(for: 3, color: .red)
            UIView.animate(withDuration: 3) {
                self.trebleStaff.transform = CGAffineTransform(translationX: 0, y: 0)
            }
            self.trombonePlayerController.playNote(.c4)
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 5) {
            self.middleLabel.animateAlpha(for: 1, reveal: true)
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 8) {
            self.middleLabel.animateAlpha(for: 1, reveal: false)
            self.trombonePlayerController.stopPlayingNote(.c4)
        }
    }
    
    func animateBassClef() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
            self.view.animateViewBackground(for: 3, color: .blue)
            UIView.animate(withDuration: 3) {
                self.bassStaff.transform = CGAffineTransform(translationX: 0, y: 0)
            }
            self.trombonePlayerController.playNote(.c3)
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 5) {
            self.middleLabel.text = "This is a Bass Clef"
            self.middleLabel.animateAlpha(for: 1, reveal: true)
        }
    }
    
    func animateDestroyTrebleClef() {
        middleLabel.animateTextChange(for: 2, text: "We only need the Bass Clef\nfor this lesson", color: middleLabel.textColor)
        trombonePlayerController.stopPlayingNote(.c3)
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
            self.middleLabel.animateAlpha(for: 1, reveal: false)
            
            UIView.transition(with: self.trebleStaff, duration: 2, options: .transitionCrossDissolve, animations: {
                self.trebleStaff.alpha = 0
            }) { finished in
                UIView.animate(withDuration: 2) {
                    self.bassStaff.transform = CGAffineTransform(translationX: 0, y: 150)
                }
                self.view.animateViewBackground(for: 2, color: .white)
            }
        }
    }
    
    func majorCSimulation() {
        topLabel.animateAlpha(for: 1, reveal: true)
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
            self.topLabel.animateTextChange(for: 2, text: "Root of C", color: .white)
            self.trombonePlayerController.playNote(.c3)
            self.bassStaff.c3Note.animateAlpha(for: 2, reveal: true)
            self.view.animateViewBackground(for: 2, color: .blue)
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 6) {
            self.topLabel.animateTextChange(for: 2, text: "Add 3rd E\n(14 cents flat)", color: self.topLabel.textColor)
            self.trombonePlayerController.playNote(.eMajor)
            self.bassStaff.eNote.animateAlpha(for: 2, reveal: true)
            self.view.animateViewBackground(for: 2, color: .purple)
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 10) {
            self.topLabel.animateTextChange(for: 2, text: "Add Perfect 5th G\n(2 cents sharp)", color: self.topLabel.textColor)
            self.trombonePlayerController.playNote(.g)
            self.bassStaff.gNote.animateAlpha(for: 2, reveal: true)
            self.view.animateViewBackground(for: 2, color: .systemIndigo)
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 14) {
            self.topLabel.animateTextChange(for: 2, text: "Add 6th A\n(16 cents flat)", color: self.topLabel.textColor)
            self.trombonePlayerController.playNote(.aMajor)
            self.bassStaff.aNote.animateAlpha(for: 2, reveal: true)
            self.view.animateViewBackground(for: 2, color: .red)
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 18) {
            self.topLabel.animateTextChange(for: 2, text: "Add 7th B (12 cents flat)\nand remove 6th", color: self.topLabel.textColor)
            self.trombonePlayerController.playNote(.bMajor)
            self.trombonePlayerController.stopPlayingNote(.aMajor)
            self.bassStaff.bNote.animateAlpha(for: 2, reveal: true)
            self.bassStaff.aNote.animateAlpha(for: 2, reveal: false)
            self.view.animateViewBackground(for: 2, color: .magenta)
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 22) {
            self.topLabel.animateTextChange(for: 2, text: "Add Root of C octave up\nand remove 7th", color: self.topLabel.textColor)
            self.trombonePlayerController.playNote(.c4)
            self.trombonePlayerController.stopPlayingNote(.bMajor)
            self.bassStaff.c4Note.animateAlpha(for: 2, reveal: true)
            self.bassStaff.bNote.animateAlpha(for: 2, reveal: false)
            self.view.animateViewBackground(for: 2, color: .systemPink)
        }
    }
    
    func minorCSimulation() {
        topLabel.animateTextChange(for: 2, text: "Now let's look at\nthe C minor chords", color: .black)
        trombonePlayerController.stopAll()
        bassStaff.c3Note.animateAlpha(for: 2, reveal: false)
        bassStaff.eNote.animateAlpha(for: 2, reveal: false)
        bassStaff.gNote.animateAlpha(for: 2, reveal: false)
        bassStaff.c4Note.animateAlpha(for: 2, reveal: false)
        view.animateViewBackground(for: 2, color: .white)
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 4) {
            self.topLabel.animateTextChange(for: 2, text: "Root of C", color: .white)
            self.trombonePlayerController.playNote(.c3)
            self.bassStaff.c3Note.animateAlpha(for: 2, reveal: true)
            self.view.animateViewBackground(for: 2, color: .blue)
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 8) {
            self.topLabel.animateTextChange(for: 2, text: "Add 3rd Eb\n (16 cents sharp)", color: self.topLabel.textColor)
            self.trombonePlayerController.playNote(.ebMinor)
            self.bassStaff.ebNote.animateAlpha(for: 2, reveal: true)
            self.view.animateViewBackground(for: 2, color: .green)
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 12) {
            self.topLabel.animateTextChange(for: 2, text: "Add Perfect 5th G\n(2 cents sharp)", color: self.topLabel.textColor)
            self.trombonePlayerController.playNote(.g)
            self.bassStaff.gNote.animateAlpha(for: 2, reveal: true)
            self.view.animateViewBackground(for: 2, color: .systemTeal)
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 16) {
            self.topLabel.animateTextChange(for: 2, text: "Add 6th A\n(19 cents sharp)", color: self.topLabel.textColor)
            self.trombonePlayerController.playNote(.aMinor)
            self.bassStaff.aNote.animateAlpha(for: 2, reveal: true)
            self.view.animateViewBackground(for: 2, color: .cyan)
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 20) {
            self.topLabel.animateTextChange(for: 2, text: "Add 7th Bb (18 cents sharp)\nand remove 6th", color: self.topLabel.textColor)
            self.trombonePlayerController.playNote(.bbMinor)
            self.trombonePlayerController.stopPlayingNote(.aMinor)
            self.bassStaff.bbNote.animateAlpha(for: 2, reveal: true)
            self.bassStaff.aNote.animateAlpha(for: 2, reveal: false)
            self.view.animateViewBackground(for: 2, color: .orange)
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 24) {
            self.topLabel.animateTextChange(for: 2, text: "Add Root of C octave up\nand remove 7th", color: .black)
            self.trombonePlayerController.playNote(.c4)
            self.trombonePlayerController.stopPlayingNote(.bbMinor)
            self.bassStaff.c4Note.animateAlpha(for: 2, reveal: true)
            self.bassStaff.bbNote.animateAlpha(for: 2, reveal: false)
            self.view.animateViewBackground(for: 2, color: .yellow)
            
            self.nextButton.animateScale(for: 2, reveal: true)
        }
    }
    
    @objc func goToNextVC() {
        trombonePlayerController.stopAll()
        let vc = SandboxViewController()
        vc.trombonePlayerController = trombonePlayerController
        navigationController?.pushViewController(vc, animated: true)
    }
}

class SandboxViewController: UIViewController {
    var trombonePlayerController: TrombonePlayerController!
    
    var notesPlaying = [Note]()
    
    let bassStaff = StaffView(of: .bass)
    
    let c3Button = TrombonePlayButton(note: .c3)
    let gButton = TrombonePlayButton(note: .g)
    let c4Button = TrombonePlayButton(note: .c4)
    
    let eMajorButton = TrombonePlayButton(note: .eMajor)
    let aMajorButton = TrombonePlayButton(note: .aMajor)
    let bMajorButton = TrombonePlayButton(note: .bMajor)
    
    let ebMinorButton = TrombonePlayButton(note: .ebMinor)
    let aMinorButton = TrombonePlayButton(note: .aMinor)
    let bbMinorButton = TrombonePlayButton(note: .bbMinor)
    
    let clearButton = UIButton(type: .custom)
    let nextButton = UIButton(type: .custom)
    
    override func loadView() {
        super.loadView()
        
        view = UIView()
        view.backgroundColor = .white
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationController?.isNavigationBarHidden = true
        
        addViews()
    }
    
    func addViews() {
        view.addSubview(bassStaff)
        
        bassStaff.pinToCenter()
        
        gButton.addTarget(self, action: #selector(playNote), for: .touchUpInside)
        view.addSubview(gButton)
        
        gButton.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        gButton.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 30).isActive = true
        gButton.heightAnchor.constraint(equalToConstant: 100).isActive = true
        gButton.widthAnchor.constraint(equalToConstant: 100).isActive = true
        
        c3Button.addTarget(self, action: #selector(playNote), for: .touchUpInside)
        view.addSubview(c3Button)
        
        c3Button.trailingAnchor.constraint(equalTo: gButton.leadingAnchor, constant: -30).isActive = true
        c3Button.topAnchor.constraint(equalTo: gButton.topAnchor).isActive = true
        c3Button.heightAnchor.constraint(equalToConstant: 100).isActive = true
        c3Button.widthAnchor.constraint(equalToConstant: 100).isActive = true
        
        c4Button.addTarget(self, action: #selector(playNote), for: .touchUpInside)
        view.addSubview(c4Button)
        
        c4Button.leadingAnchor.constraint(equalTo: gButton.trailingAnchor, constant: 30).isActive = true
        c4Button.topAnchor.constraint(equalTo: gButton.topAnchor).isActive = true
        c4Button.heightAnchor.constraint(equalToConstant: 100).isActive = true
        c4Button.widthAnchor.constraint(equalToConstant: 100).isActive = true
        
        aMajorButton.addTarget(self, action: #selector(playNote), for: .touchUpInside)
        view.addSubview(aMajorButton)
        
        aMajorButton.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        aMajorButton.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -240).isActive = true
        aMajorButton.heightAnchor.constraint(equalToConstant: 100).isActive = true
        aMajorButton.widthAnchor.constraint(equalToConstant: 100).isActive = true
        
        eMajorButton.addTarget(self, action: #selector(playNote), for: .touchUpInside)
        view.addSubview(eMajorButton)
        
        eMajorButton.trailingAnchor.constraint(equalTo: aMajorButton.leadingAnchor, constant: -30).isActive = true
        eMajorButton.topAnchor.constraint(equalTo: aMajorButton.topAnchor).isActive = true
        eMajorButton.heightAnchor.constraint(equalToConstant: 100).isActive = true
        eMajorButton.widthAnchor.constraint(equalToConstant: 100).isActive = true
        
        bMajorButton.addTarget(self, action: #selector(playNote), for: .touchUpInside)
        view.addSubview(bMajorButton)
        
        bMajorButton.leadingAnchor.constraint(equalTo: aMajorButton.trailingAnchor, constant: 30).isActive = true
        bMajorButton.topAnchor.constraint(equalTo: aMajorButton.topAnchor).isActive = true
        bMajorButton.heightAnchor.constraint(equalToConstant: 100).isActive = true
        bMajorButton.widthAnchor.constraint(equalToConstant: 100).isActive = true
        
        aMinorButton.addTarget(self, action: #selector(playNote), for: .touchUpInside)
        view.addSubview(aMinorButton)
        
        aMinorButton.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        aMinorButton.topAnchor.constraint(equalTo: aMajorButton.bottomAnchor, constant: 30).isActive = true
        aMinorButton.heightAnchor.constraint(equalToConstant: 100).isActive = true
        aMinorButton.widthAnchor.constraint(equalToConstant: 100).isActive = true
        
        ebMinorButton.addTarget(self, action: #selector(playNote), for: .touchUpInside)
        view.addSubview(ebMinorButton)
        
        ebMinorButton.trailingAnchor.constraint(equalTo: aMinorButton.leadingAnchor, constant: -30).isActive = true
        ebMinorButton.topAnchor.constraint(equalTo: aMinorButton.topAnchor).isActive = true
        ebMinorButton.heightAnchor.constraint(equalToConstant: 100).isActive = true
        ebMinorButton.widthAnchor.constraint(equalToConstant: 100).isActive = true
        
        bbMinorButton.addTarget(self, action: #selector(playNote), for: .touchUpInside)
        view.addSubview(bbMinorButton)
        
        bbMinorButton.leadingAnchor.constraint(equalTo: aMinorButton.trailingAnchor, constant: 30).isActive = true
        bbMinorButton.topAnchor.constraint(equalTo: aMinorButton.topAnchor).isActive = true
        bbMinorButton.heightAnchor.constraint(equalToConstant: 100).isActive = true
        bbMinorButton.widthAnchor.constraint(equalToConstant: 100).isActive = true
        
        clearButton.setTitle("Clear", for: .normal)
        clearButton.titleLabel?.font = UIFont.systemFont(ofSize: 15, weight: .light)
        clearButton.setTitleColor(.black, for: .normal)
        clearButton.showsTouchWhenHighlighted = true
        clearButton.layer.borderWidth = 2
        clearButton.layer.borderColor = UIColor.black.cgColor
        clearButton.layer.cornerRadius = 20
        clearButton.addTarget(self, action: #selector(clearButtonTapped), for: .touchUpInside)
        clearButton.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(clearButton)
        
        clearButton.centerXAnchor.constraint(equalTo: c3Button.centerXAnchor).isActive = true
        clearButton.topAnchor.constraint(equalTo: c3Button.bottomAnchor, constant: 40).isActive = true
        clearButton.heightAnchor.constraint(equalToConstant: 50).isActive = true
        clearButton.widthAnchor.constraint(equalToConstant: 50).isActive = true
        
        nextButton.setTitle("Next Activity", for: .normal)
        nextButton.setTitleColor(.brown, for: .normal)
        nextButton.layer.borderWidth = 2
        nextButton.layer.borderColor = UIColor.brown.cgColor
        nextButton.layer.cornerRadius = 10
        nextButton.titleLabel?.font = UIFont.systemFont(ofSize: 12, weight: .ultraLight)
        nextButton.addTarget(self, action: #selector(goToNextVC), for: .touchUpInside)
        nextButton.titleLabel?.textAlignment = .center
        nextButton.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(nextButton)

        nextButton.leadingAnchor.constraint(equalTo: clearButton.trailingAnchor, constant: 10).isActive = true
        nextButton.centerYAnchor.constraint(equalTo: clearButton.centerYAnchor).isActive = true
        nextButton.widthAnchor.constraint(equalToConstant: 80).isActive = true
        nextButton.heightAnchor.constraint(equalToConstant: 50).isActive = true
    }
    
    @objc func playNote(_ sender: UIButton) {
        guard let button = sender as? TrombonePlayButton else { return }
        
        if notesPlaying.contains(button.note) {
            notesPlaying.remove(at: notesPlaying.firstIndex(of: button.note)!)
        } else {
            notesPlaying.append(button.note)
        }
        
        switch button.note {
        case .c3:
            if trombonePlayerController.isPlayingNote(.c3) { trombonePlayerController.stopPlayingNote(.c3)
                bassStaff.c3Note.animateAlpha(for: 2, reveal: false)
            } else {
                trombonePlayerController.playNote(.c3)
                bassStaff.c3Note.animateAlpha(for: 2, reveal: true)
            }
        case .eMajor:
            if trombonePlayerController.isPlayingNote(.eMajor) { trombonePlayerController.stopPlayingNote(.eMajor)
                bassStaff.eNote.animateAlpha(for: 2, reveal: false)
            } else {
                trombonePlayerController.playNote(.eMajor)
                bassStaff.eNote.animateAlpha(for: 2, reveal: true)
            }
        case .ebMinor:
            if trombonePlayerController.isPlayingNote(.ebMinor) { trombonePlayerController.stopPlayingNote(.ebMinor)
                bassStaff.ebNote.animateAlpha(for: 2, reveal: false)
            } else {
                trombonePlayerController.playNote(.ebMinor)
                bassStaff.ebNote.animateAlpha(for: 2, reveal: true)
            }
        case .g:
            if trombonePlayerController.isPlayingNote(.g) { trombonePlayerController.stopPlayingNote(.g)
                bassStaff.gNote.animateAlpha(for: 2, reveal: false)
            } else {
                trombonePlayerController.playNote(.g)
                bassStaff.gNote.animateAlpha(for: 2, reveal: true)
            }
        case .aMajor:
            if trombonePlayerController.isPlayingNote(.aMajor) { trombonePlayerController.stopPlayingNote(.aMajor)
                bassStaff.aNote.animateAlpha(for: 2, reveal: false)
            } else {
                trombonePlayerController.playNote(.aMajor)
                bassStaff.aNote.animateAlpha(for: 2, reveal: true)
            }
        case .aMinor:
            if trombonePlayerController.isPlayingNote(.aMinor) { trombonePlayerController.stopPlayingNote(.aMinor)
                bassStaff.aNote.animateAlpha(for: 2, reveal: false)
            } else {
                trombonePlayerController.playNote(.aMinor)
                bassStaff.aNote.animateAlpha(for: 2, reveal: true)
            }
        case .bMajor:
            if trombonePlayerController.isPlayingNote(.bMajor) { trombonePlayerController.stopPlayingNote(.bMajor)
                bassStaff.bNote.animateAlpha(for: 2, reveal: false)
            } else {
                trombonePlayerController.playNote(.bMajor)
                bassStaff.bNote.animateAlpha(for: 2, reveal: true)
            }
        case .bbMinor:
            if trombonePlayerController.isPlayingNote(.bbMinor) { trombonePlayerController.stopPlayingNote(.bbMinor)
                bassStaff.bbNote.animateAlpha(for: 2, reveal: false)
            } else {
                trombonePlayerController.playNote(.bbMinor)
                bassStaff.bbNote.animateAlpha(for: 2, reveal: true)
            }
        case .c4:
            if trombonePlayerController.isPlayingNote(.c4) { trombonePlayerController.stopPlayingNote(.c4)
                bassStaff.c4Note.animateAlpha(for: 2, reveal: false)
            } else {
                trombonePlayerController.playNote(.c4)
                bassStaff.c4Note.animateAlpha(for: 2, reveal: true)
            }
        }
    }
    
    @objc func clearButtonTapped() {
        for note in notesPlaying {
            trombonePlayerController.stopPlayingNote(note)
            
            switch note {
            case .c3:
                bassStaff.c3Note.animateAlpha(for: 2, reveal: false)
            case .eMajor:
                bassStaff.eNote.animateAlpha(for: 2, reveal: false)
            case .ebMinor:
                bassStaff.ebNote.animateAlpha(for: 2, reveal: false)
            case .g:
                bassStaff.gNote.animateAlpha(for: 2, reveal: false)
            case .aMajor:
                bassStaff.aNote.animateAlpha(for: 2, reveal: false)
            case .aMinor:
                bassStaff.aNote.animateAlpha(for: 2, reveal: false)
            case .bMajor:
                bassStaff.bNote.animateAlpha(for: 2, reveal: false)
            case .bbMinor:
                bassStaff.bbNote.animateAlpha(for: 2, reveal: false)
            case .c4:
                bassStaff.c4Note.animateAlpha(for: 2, reveal: false)
            }
        }
        
        notesPlaying.removeAll()
    }
    
    @objc func goToNextVC() {
        clearButtonTapped()
        let vc = InteractiveStaffViewController()
        vc.trombonePlayerController = trombonePlayerController
        navigationController?.pushViewController(vc, animated: true)
    }
}

class InteractiveStaffViewController: UIViewController {
    var trombonePlayerController: TrombonePlayerController!
    
    var touchOrigin: CGPoint!
    
    var tintViews = [UIImageView]()
    var staffLines = [UIImageView]()
    let swipeLabel = UILabel()
    let resetStaffButton = UIButton(type: .custom)
    let backButton = UIButton(type: .custom)
    
    var colorLevel = ColorLevel.standard
    var changeColor = false
    
    var currentXAmount: CGFloat = 0
    
    var resetting = false
    
    override func loadView() {
        super.loadView()

        let view = UIView()
        view.backgroundColor = .white
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationController?.isNavigationBarHidden = true
        
        addViews()
        trombonePlayerController.playNote(.c3)
    }
    
    func addViews() {
        for i in -2...2 {
            let staffImageView = UIImageView(frame: .zero)
            staffImageView.image = UIImage.drawStaffLine(color: .clear)
            staffImageView.backgroundColor = .black
            staffImageView.translatesAutoresizingMaskIntoConstraints = false
            view.addSubview(staffImageView)
            staffLines.append(staffImageView)

            staffImageView.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
            staffImageView.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: Constants.staffWidth / 8 * CGFloat(i)).isActive = true
        }

        let bassPath = Bundle.main.path(forResource: "BassClef", ofType: "png")!
        let bassClef = UIImageView(frame: .zero)
        bassClef.image = UIImage(contentsOfFile: bassPath)!.withRenderingMode(.alwaysTemplate)
        bassClef.tintColor = .black
        bassClef.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(bassClef)
        tintViews.append(bassClef)

        bassClef.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: -16).isActive = true
        bassClef.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 15).isActive = true
        bassClef.heightAnchor.constraint(equalToConstant: bassClef.image!.size.height / 2).isActive = true
        bassClef.widthAnchor.constraint(equalToConstant: bassClef.image!.size.width / 2).isActive = true

        let halfNotePath = Bundle.main.path(forResource: "HalfNote", ofType: "png")!
        let halfNote = UIImageView(frame: .zero)
        halfNote.image = UIImage(contentsOfFile: halfNotePath)!.withRenderingMode(.alwaysTemplate)
        halfNote.tintColor = .black
        halfNote.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(halfNote)
        tintViews.append(halfNote)

        halfNote.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: -8.5).isActive = true
        halfNote.leadingAnchor.constraint(equalTo: bassClef.trailingAnchor).isActive = true
        halfNote.heightAnchor.constraint(equalToConstant: halfNote.image!.size.height / 2).isActive = true
        halfNote.widthAnchor.constraint(equalToConstant: halfNote.image!.size.width / 2).isActive = true

        let quarterNotePath = Bundle.main.path(forResource: "FlippedQuarterNote", ofType: "png")!
        let quarterNote = UIImageView(frame: .zero)
        quarterNote.image = UIImage(contentsOfFile: quarterNotePath)!.withRenderingMode(.alwaysTemplate)
        quarterNote.tintColor = .black
        quarterNote.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(quarterNote)
        tintViews.append(quarterNote)

        quarterNote.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: 0.5).isActive = true
        quarterNote.leadingAnchor.constraint(equalTo: halfNote.trailingAnchor, constant: 25).isActive = true
        quarterNote.heightAnchor.constraint(equalToConstant: quarterNote.image!.size.height / 2).isActive = true
        quarterNote.widthAnchor.constraint(equalToConstant: quarterNote.image!.size.width / 2).isActive = true

        let eighthNotePath = Bundle.main.path(forResource: "EighthNote", ofType: "png")!
        let eighthNote = UIImageView(frame: .zero)
        eighthNote.image = UIImage(contentsOfFile: eighthNotePath)!.withRenderingMode(.alwaysTemplate)
        eighthNote.tintColor = .black
        eighthNote.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(eighthNote)
        tintViews.append(eighthNote)

        eighthNote.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: -47).isActive = true
        eighthNote.leadingAnchor.constraint(equalTo: quarterNote.trailingAnchor, constant: -20).isActive = true
        eighthNote.heightAnchor.constraint(equalToConstant: eighthNote.image!.size.height / 2).isActive = true
        eighthNote.widthAnchor.constraint(equalToConstant: eighthNote.image!.size.width / 2).isActive = true
        
        swipeLabel.font = UIFont.systemFont(ofSize: 15)
        swipeLabel.textAlignment = .center
        swipeLabel.text = "Swipe Up and Down Slowly for Music"
        swipeLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(swipeLabel)

        swipeLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        swipeLabel.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -10).isActive = true
        
        resetStaffButton.setTitle("Reset Staff", for: .normal)
        resetStaffButton.setTitleColor(.black, for: .normal)
        resetStaffButton.titleLabel?.font = UIFont.systemFont(ofSize: 20, weight: .light)
        resetStaffButton.addTarget(self, action: #selector(reset), for: .touchUpInside)
        resetStaffButton.titleLabel?.textAlignment = .right
        resetStaffButton.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(resetStaffButton)

        resetStaffButton.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -10).isActive = true
        resetStaffButton.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 10).isActive = true
        resetStaffButton.heightAnchor.constraint(equalToConstant: 50).isActive = true
        resetStaffButton.widthAnchor.constraint(equalToConstant: 100).isActive = true
        
        let backArrowPath = Bundle.main.path(forResource: "BackArrow", ofType: "png")!
        backButton.setImage(UIImage(contentsOfFile: backArrowPath)!.withRenderingMode(.alwaysTemplate), for: .normal)
        backButton.imageView?.contentMode = .scaleAspectFit
        backButton.tintColor = .black
        backButton.showsTouchWhenHighlighted = true
        backButton.addTarget(self, action: #selector(backToSandbox), for: .touchUpInside)
        backButton.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(backButton)

        backButton.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 10).isActive = true
        backButton.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 10).isActive = true
        backButton.heightAnchor.constraint(equalToConstant: 50).isActive = true
        backButton.widthAnchor.constraint(equalToConstant: 50).isActive = true
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first else { return }
        
        touchOrigin = touch.location(in: view)
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first else { return }
        
        let touchLocation = touch.location(in: view)
        let difference = CGPoint(x: touchLocation.x - touchOrigin.x, y: touchLocation.y - touchOrigin.y)
        
        rotateViews(from: difference.x)
        
        playChord(from: difference.y)
        setColors(from: difference.y)
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first else { return }
        
        let touchLocation = touch.location(in: view)
        let difference = CGPoint(x: touchLocation.x - touchOrigin.x, y: touchLocation.y - touchOrigin.y)
        
        currentXAmount = difference.x
    }
    
    func rotateViews(from xValue: CGFloat) {
        for imageView in tintViews {
            UIView.animate(withDuration: 1) {
                imageView.transform = CGAffineTransform(rotationAngle: xValue / 150 + self.currentXAmount / 150)
            }
        }
        
        for staffLine in staffLines {
            UIView.animate(withDuration: 1) {
                staffLine.transform = CGAffineTransform(rotationAngle: xValue / 150 + self.currentXAmount / 150)
            }
        }
    }
    
    func playChord(from yValue: CGFloat) {
        switch yValue {
        case 100...150:
            if trombonePlayerController.isPlayingNote(.g) { trombonePlayerController.stopPlayingNote(.g) }
            trombonePlayerController.playNote(.eMajor)
        case 150...200:
            if trombonePlayerController.isPlayingNote(.aMajor) { trombonePlayerController.stopPlayingNote(.aMajor) }
            trombonePlayerController.playNote(.g)
        case 200...250:
            if trombonePlayerController.isPlayingNote(.bMajor) { trombonePlayerController.stopPlayingNote(.bMajor) }
            trombonePlayerController.playNote(.aMajor)
        case 250...300:
            if trombonePlayerController.isPlayingNote(.aMajor) { trombonePlayerController.stopPlayingNote(.aMajor) }
            if trombonePlayerController.isPlayingNote(.c4) { trombonePlayerController.stopPlayingNote(.c4) }
            trombonePlayerController.playNote(.bMajor)
        case 300...2000:
            if trombonePlayerController.isPlayingNote(.bMajor) { trombonePlayerController.stopPlayingNote(.bMajor) }
            trombonePlayerController.playNote(.c4)
        case -150...(-100):
            if trombonePlayerController.isPlayingNote(.g) { trombonePlayerController.stopPlayingNote(.g) }
            trombonePlayerController.playNote(.ebMinor)
        case -200...(-150):
            if trombonePlayerController.isPlayingNote(.aMinor) { trombonePlayerController.stopPlayingNote(.aMinor) }
            trombonePlayerController.playNote(.g)
        case -250...(-200):
            if trombonePlayerController.isPlayingNote(.bbMinor) { trombonePlayerController.stopPlayingNote(.bbMinor) }
            trombonePlayerController.playNote(.aMinor)
        case -350...(-250):
            if trombonePlayerController.isPlayingNote(.aMinor) { trombonePlayerController.stopPlayingNote(.aMinor) }
            if trombonePlayerController.isPlayingNote(.c4) { trombonePlayerController.stopPlayingNote(.c4) }
            trombonePlayerController.playNote(.bbMinor)
        case -2000...(-350):
            if trombonePlayerController.isPlayingNote(.bbMinor) { trombonePlayerController.stopPlayingNote(.bbMinor) }
            trombonePlayerController.playNote(.c4)
        default:
            if trombonePlayerController.isPlayingNote(.ebMinor) { trombonePlayerController.stopPlayingNote(.ebMinor) }
            if trombonePlayerController.isPlayingNote(.eMajor) { trombonePlayerController.stopPlayingNote(.eMajor) }
            if trombonePlayerController.isPlayingNote(.aMinor) { trombonePlayerController.stopPlayingNote(.aMinor) }
            if trombonePlayerController.isPlayingNote(.bbMinor) { trombonePlayerController.stopPlayingNote(.bbMinor) }
            if trombonePlayerController.isPlayingNote(.g) { trombonePlayerController.stopPlayingNote(.g) }
            if trombonePlayerController.isPlayingNote(.bMajor) { trombonePlayerController.stopPlayingNote(.bMajor) }
            if trombonePlayerController.isPlayingNote(.aMajor) { trombonePlayerController.stopPlayingNote(.aMajor) }
            if trombonePlayerController.isPlayingNote(.c4) { trombonePlayerController.stopPlayingNote(.c4) }
            
            if resetting {
                trombonePlayerController.stopAll()
                trombonePlayerController.playNote(.c3)
            }
        }
    }
    
    func setColors(from yValue: CGFloat) {
        switch yValue {
        case 100...150, -150...(-100):
            if colorLevel == .mild {
                changeColor = false
            } else {
                colorLevel = .mild
                changeColor = true
            }
        case 150...200, -200...(-150):
            if colorLevel == .low {
                changeColor = false
            } else {
                colorLevel = .low
                changeColor = true
            }
        case 200...250, -250...(-200):
            if colorLevel == .decent {
                changeColor = false
            } else {
                colorLevel = .decent
                changeColor = true
            }
        case 250...300, -350...(-250):
            if colorLevel == .high {
                changeColor = false
            } else {
                colorLevel = .high
                changeColor = true
            }
        case 300...1000, -1000...(-350):
            if colorLevel == .extreme {
                changeColor = false
            } else {
                colorLevel = .extreme
                changeColor = true
            }
        default:
            if colorLevel == .standard {
                changeColor = false
            } else if colorLevel == .low {
                colorLevel = .standard
                changeColor = true
            }
        }
        
        if changeColor {
            var colors = [UIColor]()
            
            switch colorLevel {
            case .standard:
                // change imageView tintColor
                for imageView in tintViews {
                    imageView.tintColor = .black
                }
                
                // animate staffLines backgroundColor
                for staffLine in staffLines {
                    staffLine.animateViewBackground(for: 1, color: .black)
                }
                
                // change backButton tintColor
                backButton.tintColor = .black
                
                // animate view backgroundColor
                view.animateViewBackground(for: 1, color: .white)
                
                // animate swipeLabel textColor
                swipeLabel.animateTextChange(for: 1, text: swipeLabel.text!, color: .black)
                
                // animate resetStaffButton titleLabel textColor
                resetStaffButton.titleLabel?.animateTextChange(for: 1, text: resetStaffButton.title(for: .normal)!, color: .black)
            case .mild, .low, .decent, .high, .extreme:
                // change imageView tintColor
                for imageView in tintViews {
                    var color = UIColor.random()
                    while colors.contains(color) {
                        color = UIColor.random()
                    }
                    
                    imageView.tintColor = color
                    colors.append(color)
                }
                
                // animate staffLines backgroundColor
                for staffLine in staffLines {
                    var color = UIColor.random()
                    while colors.contains(color) {
                        color = UIColor.random()
                    }
                    
                    staffLine.animateViewBackground(for: 1, color: color)
                    colors.append(color)
                }
                
                // change backButton tintColor
                var color = UIColor.random()
                while colors.contains(color) {
                    color = UIColor.random()
                }
                
                backButton.tintColor = color
                colors.append(color)
                
                // animate view backgroundColor
                while colors.contains(color) {
                    color = UIColor.random()
                }
                
                view.animateViewBackground(for: 1, color: color)
                colors.append(color)
                
                // animate swipeLabel textColor
                while colors.contains(color) {
                    color = UIColor.random()
                }
                
                swipeLabel.animateTextChange(for: 1, text: swipeLabel.text!, color: color)
                colors.append(color)
                
                // change resetStaffButton titleLabel textColor
                while colors.contains(color) {
                    color = UIColor.random()
                }
                
                resetStaffButton.titleLabel?.animateTextChange(for: 1, text: resetStaffButton.title(for: .normal)!, color: color)
                colors.append(color)
            }
        }
    }
    
    @objc func reset() {
        resetting = true
        colorLevel = .low
        playChord(from: 0)
        setColors(from: 0)
        rotateViews(from: -1 * currentXAmount)
        currentXAmount = 0
        resetting = false
    }
    
    @objc func backToSandbox() {
        trombonePlayerController.stopAll()
        navigationController?.popViewController(animated: true)
    }
}

// embed vc in nav controller and make it live view of playground
let master = StartViewController()
let nav = UINavigationController(rootViewController: master)
PlaygroundPage.current.liveView = nav
